#' Skeleton of R package.
#' @name TEST
#' @docType package
#' @examples
#' f <- Funzione()
#' @import methods
#' @import graphics
